<?php
/*========================================================================================
* +-+-+-+-+-+ Project    : V1P3RBOX
* |V|1|P|3|R| Author     : V1P3Rツ
* +-+-+-+-+-+ Version    : V1.0
========================================================================================*/

  /* Main Rulez */
  session_start();
  //error_reporting(0);
  @set_time_limit(ini_get('0'));

  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  /* Main Headers */ 
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  header('Cache-Control: post-check=0, pre-check=0', false);
  header('Pragma: no-cache');
  header('Access-Control-Allow-Origin: *');
  
  /* Set Main Variables */
  $sessionId = sha1(uniqid());

  $jsonFile  = './database/offers.json';

  $jsonData  = json_decode(file_get_contents($jsonFile), true);

  $smtpList  = $jsonData['smtp'];

  $offers    = $jsonData['offers'];

  ksort($smtpList);

  ksort($offers);

  /* ==========================================================================
     Start Send
     ========================================================================== */
  if($_SERVER['REQUEST_METHOD'] == 'POST'):

    if(isset($_POST['user'])):

      $_SESSION['isValid'] = true;

    else:
    
      /* Require Files */
      require_once './includes/Functions.php';

      /* Run Script */
      exit(

        json_encode(

          V1P3R_StartSend($sessionId)

        )

      );

    endif;

  endif;

?>

    <!DOCTYPE html>

    <html>

    <head>

      <meta charset="utf-8">

      <meta http-equiv="x-ua-compatible" content="ie=edge">

      <title>V1P3RBOX</title>

      <meta name="robots" content="noindex, nofollow, noimageindex">

      <meta name="description" content="">

      <meta name="viewport" content="width=device-width, initial-scale=1">

      <link rel="shortcut icon nofollow" href="https://iili.io/5rMNta.png">

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">

      <link rel="stylesheet" href="./public/stylesheets/style.css">

      <script>

        sessionStorage.setItem('jsonData', '<?php echo json_encode($jsonData); ?>')

      </script>

    </head>

    <body>

      <?php if(!isset($_SESSION['isValid'])): ?>

        <div class="background">
          
          <div class="ui tiny modal">
           
            <div class="header">
              
              Admin Login
            
            </div>
           
            <div class="content">
           
              <form id="sFrm" class="ui form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                
                <div class="field">
                
                  <label>

                    Username

                  </label>
                
                  <input type="text" name="user" placeholder="Your Username" autocomplete="off">
                
                </div>
                
                <div class="field">
                
                  <label>

                    Password

                  </label>
                
                  <input type="text" name="pass" placeholder="Your Password" autocomplete="off">
                
                </div>
                
                <button id="login" class="ui button" type="submit">
                  
                  Login

                </button>

              </form>
           
            </div>
          
          </div>

        </div>

      <?php else: ?>

        <!-- Start Modal -->
        <div class="ui mini modal">

          <div class="header">

            <i class="large frown outline icon"></i>

            There Is An Error:

          </div>

          <div class="content">

            <p>

              Please Fill All Fields Before Sending Your Message.

            </p>

          </div>

        </div> <!-- End Modal -->

        <!-- Start Aside -->
        <aside class="ui left visible vertical inverted sidebar menu">

          <a class="item" tabindex="0">

            <img class="ui image" src="https://iili.io/5rMUcN.png">

          </a>

          <a class="item" data-href="#Servers" tabindex="0">

            <i class="cloud icon"></i>

            Servers

          </a>

          <a class="item" data-href="#Header" tabindex="0">

            <i class="edit icon"></i>

            Header

          </a>

          <a class="item" data-href="#Tools" tabindex="0">

            <i class="wrench icon"></i>

            Tools

          </a>

          <a class="item" data-href="#Offers" tabindex="0">

            <i class="id card icon"></i>

            Offers

          </a>

          <a class="item" data-href="#Body" tabindex="0">

            <i class="mail icon"></i>

            Body

          </a>

          <a class="item" data-href="#Recipients" tabindex="0">

            <i class="users icon"></i>

            Recipients

          </a>

          <a class="item" data-href="#status" tabindex="0">

            <i class="info circle icon"></i>

            Send Status

          </a>

          <a class="item" tabindex="0">

            <div id="start" class="ui teal fluid animated fade button">

              <div class="visible content">Start</div>

              <div class="hidden content">

                  <i class="paper plane icon"></i>

              </div>

            </div>

          </a>

          <a class="item hiddenItem" tabindex="0">

            <div id="stop" class="ui fluid animated fade button">

              <div class="visible content">Stop</div>

              <div class="hidden content">

                  <i class="ban icon"></i>

              </div>

            </div>

          </a>

          <a class="item hiddenItem" tabindex="0">

            <div class="ui teal tiny indicating progress">

              <div class="bar"></div>

              <div class="label"></div>

            </div>

          </a>

        </aside> <!-- End Aside -->

        <!-- Start Pusher -->
        <div class="dimmed pusher">

          <section class="ui container">

            <!-- Start Breadcrumb -->
            <div class="ui mini breadcrumb">

              <div class="active section">
                
                ServerIP: <?php echo $_SERVER['SERVER_ADDR']; ?>
              
              </div>

              <i class="right angle icon divider"></i>

              <a

                class="section"

                href="<?php echo 'https://ipapi.co/' . $_SERVER['SERVER_ADDR'] . '/'; ?>"

                target="_blank"

              >

                IP Geolocation

              </a>

              <i class="right arrow icon divider"></i>
              
              <a

                class="section"

                href="<?php echo './public/tools/V1P3RCHECK.php?ServerIP=' . $_SERVER['SERVER_ADDR']; ?>"

                target="_blank"

              >
                
                Check Blacklist 

              </a>

              <span class="divider">|</span>

              <div class="active section">

                PHP Version: <?php echo phpversion(); ?>

              </div>

            </div> <!-- End Breadcrumb -->

            <div class="ui section divider"></div>
            
            <form id="sFrm" class="ui form" method="post" action="">

              <div class="ui text">

                <h4 data-href="#Servers" class="ui top attached block header raised segment">

                  Servers Section

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="two fields">

                    <div class="field">

                      <label>

                        Servers

                      </label>

                      <textarea

                        name="server"

                        placeholder="If You Don't Have SMTP Login Information's, Leave Blank To Send With Localhost.&#10;&#10;Format 1: Host:Port:User:Pass:TLS&#10;&#10;Format 2: Host:Port:TLS"

                      ></textarea>

                    </div>

                    <div class="field">

                      <div class="two fields">

                        <div class="field">

                          <label>

                            Pause Send

                          </label>

                          <input

                            type="text"

                            name="pause"

                            value="3"

                          >

                        </div>

                        <div class="field">

                          <label>

                            Pause After

                          </label>

                          <input

                            type="text"

                            name="pauseAfter"

                            value="5"

                          >

                        </div>

                      </div>

                      <div class="two fields">

                        <div class="field">

                          <label>

                            Rotation After

                          </label>

                          <input

                            type="text"

                            name="nrotat"

                            value="0"

                          >

                        </div>

                        <div class="field">

                          <label>

                            Reconnect After

                          </label>

                          <input

                            type="text"

                            name="reconnect"

                            value="0"

                          >

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="field">

                    <div class="two fields">

                      <div class="field">

                        <div class="two fields">

                          <div class="field">

                            <label>

                              Servers List

                            </label>

                            <select class="ui fluid dropdown" name="smtpList">

                              <?php

                                foreach ($smtpList as $key => $smtp): ?>

                                <option value="<?php echo $smtp; ?>">

                                  <?php echo $key; ?>

                                </option>

                              <?php endforeach; ?>

                            </select>

                          </div>

                          <div class="field">

                            <label>

                              Queue Concurrency

                            </label>

                            <input

                              type="text"

                              name="concurrency"

                              value="6"

                            >

                          </div>

                        </div>

                      </div>

                      <div class="field">

                        <div class="two fields">

                          <div class="field">

                            <label>

                              Email's In Bcc

                            </label>

                            <input

                              type="text"

                              name="inBCC"

                              value="0"

                            >

                          </div>

                          <div class="field">

                            <label>

                              Debugging

                            </label>

                            <select class="ui fluid dropdown" name="debug">

                              <option value="0">

                                Off

                              </option>

                              <option value="1">

                                Client

                              </option>

                              <option value="2">

                                Server

                              </option>

                              <option value="3">

                                Connection

                              </option>

                              <option value="4">

                                Low Level

                              </option>

                            </select>

                          </div>

                        </div>

                      </div>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#Header" class="ui top attached block header">

                  Header Section

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="two fields">

                    <div class="field">

                      <label>

                        Custom Header

                      </label>

                      <textarea name="headers">Message-ID: <[[az-09-{20}]]@[[domain]]>&#10;X-Mailer: V1P3RBOX v1.0-Ref[[09-{2}]]&#10;Auto-Submitted: auto-generated&#10;X-Auto-Response-Suppress: OOF, AutoReply&#10;X-Abuse: Please report abuse here <mailto:abuse@[[domain]]?c=[[09-{10}]]></textarea>

                    </div>

                    <div class="field">

                      <div class="two fields">

                        <div class="field">

                          <label>

                            Content Type

                          </label>

                          <select class="ui fluid dropdown" name="contentType">

                            <option value="text/html">

                              text/html

                            </option>

                            <option value="text/plain">

                              text/plain

                            </option>

                            <option value="multipart/alternative">

                              multipart/alternative

                            </option>

                          </select>

                        </div>

                        <div class="field">

                          <label>

                            Charset

                          </label>

                          <select class="ui fluid dropdown" name="charset">

                            <option value="UTF-8">

                              UTF-8

                            </option>

                            <option value="US-ASCII">

                              US-ASCII

                            </option>

                            <option value="ISO-8859-1">

                              ISO-8859-1

                            </option>

                          </select>

                        </div>

                      </div>

                      <div class="two fields">

                        <div class="field">

                          <label>

                            Content-Transfer-Encoding

                          </label>

                          <select class="ui fluid dropdown" name="encoding">

                            <option value="7bit">

                              7bit

                            </option>

                            <option value="8bit">

                              8bit

                            </option>

                            <option value="base64">

                              Base64

                            </option>

                            <option value="binary">

                              Binary

                            </option>

                            <option value="quoted-printable">

                              Quoted-Printable

                            </option>

                          </select>

                        </div>

                        <div class="field">

                          <label>

                            Priority

                          </label>

                          <select class="ui fluid dropdown" name="priority">

                            <option value="">

                              Default

                            </option>

                            <option value="5">

                              Low

                            </option>

                            <option value="3" selected>

                              Normal

                            </option>

                            <option value="1">

                              High

                            </option>

                          </select>

                        </div>

                      </div>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#Tools" class="ui top attached block header">

                  Tools Section

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="two fields">

                    <div class="field">

                      <div class="field">

                        <h5 class="ui header">

                          Generator Setting

                        </h5>

                        <div class="ui labeled input">

                          <div class="ui basic label">

                            <div class="ui toggle checkbox">

                              <input type="checkbox" tabindex="0" class="hidden" value="AZ">

                              <label>

                                Range A-Z

                              </label>

                            </div>

                            &nbsp;&nbsp;&nbsp;

                            <div class="ui toggle checkbox">

                              <input type="checkbox" tabindex="0" class="hidden" value="az">

                              <label>

                                Range a-z

                              </label>

                            </div>

                            &nbsp;&nbsp;&nbsp;

                            <div class="ui toggle checkbox">

                              <input type="checkbox" tabindex="0" class="hidden" value="09">

                              <label>

                                Range 0-9

                              </label>

                            </div>

                          </div>

                          <input type="text" name="length" placeholder="Length">

                        </div>

                      </div>

                      <div class="field">

                        <h5 class="ui header">

                          Pattern Value

                        </h5>

                        <div class="ui action input">

                          <input type="text" name="pattern" placeholder="Pattern">

                          <button type="button" class="ui teal right labeled icon button" id="pBtn">

                            <i class="random icon"></i>

                            Get Pattern

                          </button>

                        </div>

                      </div>

                      <div class="field">

                        <div class="two fields">

                          <div class="field">

                            <label>

                              Number Of Feeds

                            </label>

                            <input

                              type="text"

                              name="feedsRow"

                              value="1"

                            >

                          </div>

                          <div class="field">

                            <label>

                              Random Send After

                            </label>

                            <input

                              type="text"

                              name="randomSend"

                              value="0"

                            >

                          </div>

                        </div>

                      </div>

                      <div class="field">

                        <label>

                          Feeds Wrapper

                        </label>

                        <textarea name="feedsWrapper"><div style="padding: 10px">&#10;&nbsp;<img src="[[feed_img]]" alt="[[feed_title]]" style="width: 50px">&#10;&nbsp;<h5>&#10;&nbsp;&nbsp;<a href="[[feed_link]]" style="text-decoration:none; font-size: 12px;">[[feed_title]]</a>&#10;&nbsp;</h5>&#10;&nbsp;<p style="font-size: 12px;">[[feed_desc]]</p>&#10;</div></textarea>

                      </div>

                    </div>

                    <div class="field">

                      <label>

                        Instruction

                      </label>

                      <div class="instruction">

                        <ol class="ui list">

                          <li value="*"> General Tags

                            <ol>

                              <li value="-">

                                <span>[[AZ-az-09-{N}]]</span>:&nbsp;

                                Random String Generator

                              </li>

                              <li value="-">

                                <span>[[date]]</span>:&nbsp;

                                Date (<?php echo date('m/d/Y') ?>)

                              </li>

                              <li value="-">

                                <span>[[time]]</span>:&nbsp;

                                Time (<?php echo date('H:m:s') ?>)

                              </li>

                              <li value="-">

                                <span>[[email]]</span>:&nbsp;

                                Reciver Email

                              </li>

                              <li value="-">

                                <span>[[user]]</span>:&nbsp;

                                Email User (email_user@domain.com)

                              </li>

                              <li value="-">

                                <span>[[domain]]</span>:&nbsp;

                                Server Domain

                              </li>

                              <li value="-">

                                <span>[[link]]</span>:&nbsp;

                                Your Link

                              </li>

                              <li value="-">

                                <span>[[image]]</span>:&nbsp;

                                Your Embedded Image

                              </li>

                            </ol>

                          </li>

                          <li value="*"> Feeds Tags

                            <ol>

                              <li value="-">

                                <span>[[feeds]]</span>:&nbsp;

                                If You Want To Use Feeds In Your HTML Message

                              </li>

                              <li value="-">

                                <span>[[feed_img]]</span>:&nbsp;

                                Get Feed Image

                              </li>

                              <li value="-">

                                <span>[[feed_title]]</span>:&nbsp;

                                Get Feed Title

                              </li>

                              <li value="-">

                                <span>[[feed_link]]</span>:&nbsp;

                                Get Feed URL

                              </li>

                              <li value="-">

                                <span>[[feed_desc]]</span>:&nbsp;

                                Get Feed Description

                              </li>

                            </ol>

                          </li>

                          <li value="*"> Example

                            <ol>

                              <li value="-">

                                Hello <strong>[[user]]</strong> ->

                                Hello <strong>user</strong>

                              </li>

                              <li value="-">

                                Your Code Is <strong>[[AZ-az-09-{10}]]</strong> ->

                                Your Code Is <strong>A4s5FhrN9m</strong>

                              </li>

                            </ol>

                          </li>

                        </ol>

                        <small>

                          &copy; 2018-<?php echo date('Y'); ?> By <a href="https://t.me/V1P3R_404/" target="_blank">V1P3Rツ</a> - All rights reserved.

                        </small>

                      </div>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#Offers" class="ui top attached block header">

                  Offers Section

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="three fields">

                    <div class="field">

                      <label>

                        Offers List

                      </label>

                      <select class="ui fluid dropdown" name="offers">

                        <?php

                          foreach ($offers as $key => $value): ?>

                          <option

                            value="<?php echo $key; ?>"

                            <?php if($key == 'Default') echo 'selected'; ?>

                          >

                            <?php echo $key; ?>

                          </option>

                        <?php endforeach; ?>

                      </select>

                    </div>

                    <div class="field">

                      <label>

                        BCC Name

                      </label>

                      <input

                        type="text"

                        name="bccName"

                        value="Undisclosed Recipients"

                      >

                    </div>

                    <div class="field">

                      <label>

                        BCC Mail

                      </label>

                      <input

                        type="text"

                        name="bccMail"

                      >

                    </div>

                  </div>

                  <div class="two fields">

                    <div class="field">

                      <label>

                        From Name

                      </label>

                      <div class="ui left action input">

                        <select class="ui dropdown" name="fromNameEncoding">

                            <option value="">

                              Default

                            </option>

                            <option value="7bit">

                              7bit

                            </option>

                            <option value="base64" selected>

                              Base64

                            </option>

                            <option value="binary">

                              Binary

                            </option>

                            <option value="quoted-printable">

                              Quoted-Printable

                            </option>

                        </select>

                        <input

                          type="text"

                          name="fromName"

                        >

                      </div>

                    </div>

                    <div class="field">

                      <label>

                        Subject

                      </label>

                      <div class="ui left action input">

                        <select class="ui dropdown" name="subjectEncoding">

                            <option value="">

                              Default

                            </option>

                            <option value="7bit">

                              7bit

                            </option>

                            <option value="base64" selected>

                              Base64

                            </option>

                            <option value="binary">

                              Binary

                            </option>

                            <option value="quoted-printable">

                              Quoted-Printable

                            </option>

                        </select>

                        <input

                          type="text"

                          name="subject"

                        >

                      </div>

                    </div>

                  </div>

                  <div class="three fields">

                    <div class="field">

                      <label>

                        From Email

                      </label>

                      <div class="ui labeled input">

                        <div class="ui basic label">

                          <div class="ui toggle checkbox">

                            <input

                              type="checkbox"

                              tabindex="0"

                              class="hidden"

                              name="emailAsLogin"

                            >

                            <label>

                              E.A.L

                            </label>

                          </div>

                        </div>

                        <input

                          type="text"

                          name="fromMail"

                          placeholder="from@[domain]"

                        >

                      </div>

                    </div>

                    <div class="field">

                      <label>

                        Reply-To

                      </label>

                      <div class="ui labeled input">

                        <div class="ui basic label">

                          <div class="ui toggle checkbox">

                            <input

                              type="checkbox"

                              tabindex="0"

                              class="hidden"

                              name="replyAsLogin"

                            >

                            <label>

                              R.A.L

                            </label>

                          </div>

                        </div>

                        <input

                          type="text"

                          name="replyTo"

                          placeholder="reply@[domain]"

                        >

                      </div>

                    </div>

                    <div class="field">

                      <label>

                        Return Path

                      </label>

                      <div class="ui labeled input">

                        <div class="ui basic label">

                          <div class="ui toggle checkbox">

                            <input

                              type="checkbox"

                              tabindex="0"

                              class="hidden"

                              name="confirmReading"

                            >

                            <label>

                              C.R

                            </label>

                          </div>

                        </div>

                        <input

                          type="text"

                          name="returnPath"

                          placeholder="return@[domain]"

                        >

                      </div>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#Body" class="ui top attached block header">

                  Body Section

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="two fields">

                    <div class="field">

                      <label>

                        Link

                      </label>

                      <input

                        type="text"

                        name="link"

                        placeholder="https://example.com"

                      >

                    </div>

                    <div class="field">

                      <label>

                        Attachments

                      </label>

                      <div class="ui action labeled input">

                        <div class="ui basic label">

                          <div class="ui toggle checkbox">

                            <input

                              type="checkbox"

                              tabindex="0"

                              class="hidden"

                              name="embedIMG"

                            >

                            <label>

                              Embedded Image

                            </label>

                          </div>

                        </div>

                        <input type="text" placeholder="Your File Name" readonly>

                        <input type="file" class="hiddenItem" name="attachments" multiple>

                        <button id="uBtn" type="button" class="ui teal right labeled icon button">

                          <i class="cloud upload icon"></i>

                          Upload

                        </button>

                      </div>

                      <canvas class="hiddenItem"></canvas>

                      <input type="hidden" name="sessionId" value="<?php echo $sessionId; ?>">

                    </div>

                  </div>

                  <div class="two fields">

                    <div class="field">

                      <div class="two fields">

                        <div class="field">

                          <label>

                            Open Redirect

                          </label>

                          <select class="ui fluid dropdown" name="openRedirect">

                            <option value="">

                              No Redirect

                            </option>

                            <option value="Enewsletter">

                              Enewsletter

                            </option>

                          </select>

                        </div>

                        <div class="field">

                          <label>

                            Shortener

                          </label>

                          <select class="ui fluid dropdown" name="useShortener">

                            <option value="">

                              No Shortener

                            </option>

                            <option value="Shorturl.at">

                              Shorturl.at

                            </option>

                          </select>

                        </div>

                      </div>

                    </div>

                    <div class="field">

                      <div class="field">

                        <div class="three fields">

                          <div class="field">

                            <label>

                              Context Font

                            </label>

                            <input

                              type="text"

                              name="contextFont"

                              value="6px sans-serif"

                            >

                          </div>

                          <div class="field">

                            <label>

                              Context Color

                            </label>

                            <input

                              type="text"

                              name="contextColor"

                              value="#FFF"

                            >

                          </div>

                          <div class="field">

                            <label>

                              Context Position

                            </label>

                            <input

                              type="text"

                              name="contextPosition"

                              value="10"

                            >

                          </div>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="two fields">

                    <div class="field">

                      <label>

                        Creative

                      </label>

                      <textarea name="letter"></textarea>

                    </div>

                    <div class="field">

                      <label>

                        Preview

                      </label>

                      <iframe class="preview"></iframe>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#Recipients" class="ui top attached block header">

                  Recipients Section

                  (<a href="./public/tools/V1P3RDATA.php" target="_blank">
                            
                    Email Extractor

                  </a>

                  &

                  <a href="./public/tools/V1P3RBOUNCE.php" target="_blank">
                            
                    Bounce Remover

                  </a>

                  &

                  <a href="./public/tools/V1P3RCOMBO.php" target="_blank">
                            
                    ISP Combolist Cracker

                  </a>)

                </h4>

                <div class="ui teal bottom attached segment">

                  <div class="two fields">

                    <div class="field">

                      <label>

                        Recipients

                      </label>

                      <textarea name="recipients"></textarea>

                    </div>

                    <div class="field">

                      <label>

                        Failures

                      </label>

                      <textarea name="failures"></textarea>

                    </div>

                  </div>

                </div>

                <div class="ui section divider"></div>

                <h4 data-href="#status" class="ui top attached block header">

                  Send Status Section

                  (<a tabindex="0" id="CheckScore">
                          
                    Check SpamAssassin Score

                  </a>)

                </h4>

                <div class="ui teal bottom attached segment">

                  <table class="ui very basic table compact fixed four column single line status">

                  </table>

                </div>

              </div>

            </form>

          </section>

        </div> <!-- End Pusher -->

      <?php endif; ?>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/d3-collection/1.0.5/d3-collection.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/d3-dispatch/1.0.3/d3-dispatch.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/d3-request/1.0.6/d3-request.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/d3-queue/3.0.7/d3-queue.min.js"></script>

        <script src="./public/javascripts/script.js"></script>

    </body>

    </html>